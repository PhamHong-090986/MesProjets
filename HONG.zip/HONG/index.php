<?php
require 'Controller/Routeur.php';
require 'config.php';
$routeur = new Routeur();
$routeur->routerRequete();