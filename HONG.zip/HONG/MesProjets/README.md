# MonProjetdePHP
Projet de création un blog pour un écrivain en PHP/POO en respectant l’architecture MVC.
LE SUJET:  
"Vous décrochez un contrat avec un écrivain. En tant que développeur, vous devez lui monter une plateforme pour son prochain ouvrage. Seule contrainte : votre client ne veut pas de site sur Wordpress. Vous devez donc développer un moteur de blog en PHP et MySQL."

COMPETENCES: 
Créer un site internet, de sa conception à sa livraison
Insérer ou modifier les données d’une base
Organiser le code en langage PHP
Analyser les données utilisées par le site ou l’application
Récupérer les données d’une base
Construire une base de données
Récupérer la saisie d’un formulaire utilisateur en langage PHP
