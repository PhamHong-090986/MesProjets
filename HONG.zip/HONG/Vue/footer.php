<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/d3js/5.9.0/d3.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
 
</head>
<body>
<footer>
  <div class="container-fluid">
    <div class="row">
      <div id="block1" class="col-sm-4" style="border">
          <h1>Mention légale</h1>
          <a  href="index.php?action=connexion" > Accès Admin </a>
            <p><i>Site réaliser par: PHAM Hong,Camille</i></p>
</div>


      <div id="block2" class="col-sm-4" style="border">
          <h1>Suivez-moi </h1>
          <hr>
          <img src="<?= ASSETS;?>photo/facebook.png" alt="Facebook" />
      <img src="<?= ASSETS;?>photo/twitter.png" alt="Twitter" />
      <img src="<?= ASSETS;?>/photo/vimeo.png" alt="Vimeo" />
</div>


      <div id="block3" class="col-sm-4" style="border">
          <h1>Projet 3</h1>
            <p>Créer un Blog pour un écrivain</p>
            <p>Bootstrap, Html/css, PHP MVC, PHP OPP</p>
</div>
</body>
</html>
