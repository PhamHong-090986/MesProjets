<nav>
    <h1>Un roman de Jean FORTEROCHE</h1>
    <img src="<?= ASSETS;?>photo/Alaska.jpg" width="100%" height="60%" alt=""/>
    <ul>

        <li>       
            <a href="index.php?action=connexion" title="aller à la connexion">
                CONNEXION
            </a>
        </li>
        <li>
            <a href="<?= HOST;?>index.php" title="aller à l'accueil"> ACCUEIL</a>
        </li>
        <li>
            <a href="index.php?action=chapitre"  title="aller aux chapitres">
                LES CHAPITRES
            </a>
        </li>
        
    </ul>           
</nav>

